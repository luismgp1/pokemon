from flask import Flask, render_template, request, redirect, url_for
import requests

app =  Flask(__name__)

@app.route('/')
def principal(): 
    #return responseData.json()
    #return render_template('dashboard.html',data = responseData)     
    return render_template('Dashboard.html')
    

@app.route('/entrenador',methods=['POST'])
def trainerCreate():
    trainer_api = 'http://127.0.0.1:3000/trainer/entrenador'
    entrenador = request.form['entrenador']
    responseData = requests.post(trainer_api, {"trainer": entrenador })    
    #print('DATA AQUI')  
    #print( responseData.json() )
    return render_template('Pokemon.html',data = responseData.json())

@app.route('/pokemon',methods=['POST'])
def pokemonData():
    pokemon_api = 'http://127.0.0.1:3000/pokemon/'
    #print(request.form)
    pokemon = request.form['pokemon']
    entrenador = request.form['entrenador']
    responseData=requests.get(pokemon_api + pokemon)
    responseData = responseData.json()
    #data = { "name": "", "id": "" }
    if "name" in responseData:
        data = { "name": responseData['name'], "id":  responseData['id'] , "sprite": responseData['sprites']['front_default'] , "trainer":entrenador}
    else:
        data = {"trainer":entrenador}
    return render_template('Pokemon.html',data = data)

@app.route('/capturar',methods=['POST'])
def pokemonCapturar():
    pokemon_api = 'http://127.0.0.1:3000/trainer'
    
    if request.form['capturar'] == "SI":
        form = {
        "trainer": request.form['entrenador'],
        "sprite": request.form['sprite'],
        "nombre": request.form['nombre'],
        "numero": request.form['id'],
        }    
        
        responseData=requests.post(pokemon_api,form)
        responseData = responseData.json()	     
        print(responseData)   
        return render_template('Pokemon.html',data = responseData)
    else:
        data = {
            "trainer": request.form['entrenador'],
            "pokemons": request.form['pokemons']
        }
        return render_template('Pokemon.html',data = data)


@app.route('/<trainer>',methods=['POST'])
def trainerSave(trainer):
    trainer_api = 'http://127.0.0.1:3000/trainer/'
    numero = request.form['id']
    nombre = request.form['nombre']
    responseData = requests.post(trainer_api, { "numero": numero, "nombre":nombre, "trainer": trainer })      
    return redirect('http://127.0.0.1:5000/'+ trainer)
    #redirect(url_for('trainerData',trainer))




if __name__ == '__main__':
    app.run(debug=True)